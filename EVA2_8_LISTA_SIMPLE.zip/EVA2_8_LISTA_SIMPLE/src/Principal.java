
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        // TODO code application logic here
        Lista miLista = new Lista();
        miLista.add(new Nodo(4));
        miLista.print();
        miLista.add(new Nodo(4));
        miLista.add(new Nodo(4));
        miLista.add(new Nodo(4));
        miLista.add(new Nodo(4));
        miLista.addBegin(new Nodo(99999));
        miLista.insertAt(2, new Nodo(5555555));
        miLista.print();
        miLista.deleteAt(2);
        miLista.print();
        miLista.add(new Nodo(200));
        miLista.print();
        System.out.println("El elemento 5 es:"+miLista.findAt(4));
    }

}
