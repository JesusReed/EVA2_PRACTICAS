
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Lista {

    private Nodo inicio;
    private Nodo fin;

    public Lista() {
        this.inicio = null;
        this.fin = null;
    }

    //DEVUELVE TRUE SI LA LISTA ESTÁ VACÍA
    public boolean isEmpty() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    //AGREGAR UN NODO AL FINAL DE LA LISTA
    public void add(Nodo nuevo) {
        if (isEmpty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            /*Nodo temp = inicio;
            while (temp.getSiguiente() != null) {
                temp = temp.getSiguiente();
                temp.setSiguiente(nuevo);*/
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
    }

    //IMPRIMIR LISTA
    public void print() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.print(temp.getValor() + " - ");
            temp = temp.getSiguiente();
        }
        System.out.println("");
    }

    //CANTIDAD DE ELEMENTOS EN LA LISTA
    public int size() {
        int iCont = 0;
        Nodo temp = inicio;
        while (temp != null) {
            iCont++;
            temp = temp.getSiguiente();
        }
        return iCont;
    }

    public void addBegin(Nodo nuevo) {
        //VERIFICAR SI LA LISTA ESTÁ VACÍA
        if (isEmpty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        }
    }

    public void insertAt(int pos, Nodo nuevo) {
        int iTama = size();
        if (pos < 0 || pos >= iTama) {
            try {
                throw new Exception("Posición inválida");
            } catch (Exception ex) {
                Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            if (pos == 0) {
                addBegin(nuevo);
            } else {
                int iCont = 0;

                Nodo temp = inicio;
                while (iCont < (pos - 1)) {
                    temp = temp.getSiguiente();
                    iCont++;
                }
                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);
            }
        }
    }
    public void clear(){
        inicio = null;
        fin = null;
    }
    public void deleteAt(int pos){
        try {
            //OMITIENDO VERIFICACION
            //BORRAR LA PRIMERA
            if(isEmpty()== true){
                try {
                    throw new Exception("La lista está vacía");
                } catch (Exception ex) {
                    Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            int iTama = size();
            if((pos<0)||pos>=iTama)
                throw new Exception("La posición es inválida");
            if (iTama==1) {//SÓLO HAY UN NODO
                clear();
            }else{
                if (pos==0) {//BORRAR EL PRIMER NODO
                    inicio= inicio.getSiguiente();
                }else{
                    int iCont = 0;
                    
                    Nodo temp = inicio;
                    while (iCont < (pos - 1)) {
                        temp = temp.getSiguiente();
                        iCont++;
                    }
                    temp.setSiguiente(temp.getSiguiente().getSiguiente());
                    if(pos==(iTama-1)){
                        fin = temp;
                    }
                }
            }
            if(pos==0){
                inicio = inicio.getSiguiente();
            }
            //UN SOLO NODO
            if(size()==1){
                inicio=null;
                fin=null;
            }
            //BORRAR LA ULTIMA
        } catch (Exception ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public int findAt(int pos){
        int iCont=0;
        Nodo temp= inicio;
        while (iCont < (pos - 1)) {
                    temp = temp.getSiguiente();
                    iCont++;
                }
        return temp.getValor();
    }
}
