
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//      Scanner tecladin = new Scanner(System.in);
//    System.out.println("Introduce valores");
//       int iVal=tecladin.nextInt();
        System.out.println("Factorial de 5 es "+calculaFactorial(5));
       
    }
     public static int calculaFactorial(int iVal){
         System.out.println("Inicio "+iVal);
          if(iVal==0){
              return 1;
          }else{
              return iVal*calculaFactorial(iVal-1);
          }         
     }

}
