
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aaron
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner num= new Scanner(System.in);
        System.out.println("Ingrese numero");
        int txt = num.nextInt();
       if(esPrimoIneficiente(txt)){
            System.out.println("Es primo");
       }else{ 
            System.out.println("No es primo");
    }
    }
    public static boolean esPrimoIneficiente(int valor){
        boolean bResu=true;
        for (int i = 2; i < valor; i++) {
            if((valor%i)==0){
                bResu=false;
                break;
            }
            
        }
        return bResu;
    }
    
}
