
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(fibo(8));
    }
    public static int fibo(int iPos ){
        if(iPos==0){
            return 0;
        }else if (iPos==1){
            return 1;
        }else{
            return fibo(iPos-1)+fibo(iPos-2);
        }
    }
}
