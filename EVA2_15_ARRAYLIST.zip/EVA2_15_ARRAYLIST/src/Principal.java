
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> aMiArrayList = new ArrayList<Integer>();
        aMiArrayList.add(100);
        aMiArrayList.add(200);
        aMiArrayList.add(300);
        aMiArrayList.add(400);
        aMiArrayList.add(500);
        System.out.print(aMiArrayList);
    }
    
}
