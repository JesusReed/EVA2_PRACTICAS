/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Nodo {
    private int valor;

   
    private Nodo izq;
    private Nodo der;

    public void setIzq(Nodo izq) {
        this.izq = izq;
    }

    public void setDer(Nodo der) {
        this.der = der;
    }

    public Nodo getIzq() {
        return izq;
    }

    public Nodo getDer() {
        return der;
    }
    
    public Nodo(int valor){
        this.valor = valor;
        this.izq = null;
        this.der = null;
    }
    
     public int getValor() {
        return valor;
    }

    public Nodo getSiguiente() {
        return izq;
    }
    public Nodo getPrevio() {
        return der;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public void setSiguiente(Nodo siguiente) {
        this.izq = siguiente;
    }

    public Nodo(int valor, Nodo siguiente) {
        this.valor = valor;
        this.izq = siguiente;
    }

    public void setPrevio(Nodo previo) {
        this.der = previo;
    }
    
    
}
