/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CIESPN
 */
public class Arbol {

    private Nodo root;

    public Arbol() {
        root = null;
    }

    public void agregarNodo(Nodo nuevo) {
        agregarNodoRec(root, nuevo);
    }

    public void agregarNodoRec(Nodo actual, Nodo nuevo) {
        if (root == null) {//ARBOL VACÍO
            root = nuevo;
        } else {
            if (nuevo.getValor() > actual.getValor()) {//MAYOR --> DERECHA
                if (actual.getDer() == null) {
                    actual.setDer(nuevo);
                } else {//YA HAY UN NODO
                    agregarNodoRec(actual.getDer(), nuevo);
                }
            } else if (nuevo.getValor() < actual.getValor()) {//MENOR --> IZQUIERDA
                if (actual.getIzq() == null) {
                    actual.setIzq(nuevo);
                } else {
                    agregarNodoRec(actual.getIzq(), nuevo);
                }
            } else if (nuevo.getValor() == actual.getValor()) {
                System.out.println("Ya existe el valor");
            }
        }
    }

    public void imprimePostOrder() {
        postOrder(root);

    }

    private void postOrder(Nodo actual) {
        if (actual != null) {
            //LEER IQZ
            postOrder(actual.getIzq());
            //LEER DER
            postOrder(actual.getDer());
            //IMPRIMIR
            System.out.print(actual.getValor() + " - ");
        }
    }
    
    public void imprimePreOrder() {
        preOrder(root);

    }

    private void preOrder(Nodo actual) {
        if (actual != null) {
            //IMPRIMIR
            System.out.print(actual.getValor() + " - ");
            //LEER IQZ
            preOrder(actual.getIzq());
            //LEER DER
            preOrder(actual.getDer());
            
            
        }
    }
    
    public void imprimeInOrder() {
        inOrder(root);

    }

    private void inOrder(Nodo actual) {
        if (actual != null) {
            //LEER IQZ
            inOrder(actual.getIzq());
            //IMPRIMIR
            System.out.print(actual.getValor() + " - ");
            //LEER DER
            inOrder(actual.getDer());
            
            
        }
    }
}
